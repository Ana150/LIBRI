package helpers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateFormat {
    private String dateFormat = "dd-MM-yyyy HH:mm:ss";
    private String lacale = "pt-BR";
    private SimpleDateFormat sdf = null;

    public DateFormat(){
        this.sdf = new SimpleDateFormat(this.dateFormat, new Locale(this.lacale));
    }

    public String getDateFormat (){
        return this.sdf.format(new Date());
    }
}
