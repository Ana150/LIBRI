package helpers;

public class Login {
    private static int cod_usuario;

    public static int getCod_usuario() {
        return cod_usuario;
    }

    public static void setCod_usuario(int cod_usuario) {
        Login.cod_usuario = cod_usuario;
    }
}
